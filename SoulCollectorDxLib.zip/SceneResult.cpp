#include "SceneResult.h"
#include "Application.h"
extern std::unique_ptr<Application> pApp;

SceneResult::SceneResult()
{
}


SceneResult::~SceneResult()
{
}

void SceneResult::Render(){

}