#pragma once
#include "EnemyBase.h"
class EnemyBigShield :
	public EnemyBase
{

	public:
		EnemyBigShield();
		~EnemyBigShield();

		//void Render()override;
};

