#pragma once
#include "Include.h"
#include "Enemy.h"
#include "DataEnemy.h"


class BattleEnemy{

	private:
		
		int const m_ELEMENTFIRST, m_ELEMENTSECOUND, m_ELEMENTTHIRD;
		int const m_ELEMENTFOURTH, m_ELEMENTFIFTH;

		int m_enemyPotion;

		std::vector<Enemy>m_pVecEnemy;

		std::unique_ptr<DataEnemy> m_pDataEnemy;

	public:
		BattleEnemy();
		~BattleEnemy();
		void Render();

		
		template<typename T>
		void VectorRemove(std::vector<T>&vector, unsigned int element);		//vector�R���e�i�̗v�f���폜

		template<typename T>
		bool IsDead(std::vector<T>&vector, unsigned int element, int);		//�G�̎���ł邩�����Ă邩�̔��� ��:true/��:false
};

