#pragma once
#include "Application.h"
#include "Include.h"
class Entry
{
	public:
		Entry();
		~Entry();


};

