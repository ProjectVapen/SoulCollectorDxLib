#include "TypeAttributeBase.h"


TypeAttributeBase::TypeAttributeBase()
{
}


TypeAttributeBase::~TypeAttributeBase()
{
}
