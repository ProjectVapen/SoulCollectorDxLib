#include "BattleCard.h"


BattleCard::BattleCard()
{
}


BattleCard::~BattleCard()
{
}
