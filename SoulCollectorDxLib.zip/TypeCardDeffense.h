#pragma once
#include "TypeCardBase.h"
#include "Include.h"
class TypeCardDeffense:
	public TypeCardBase
{
public:
	TypeCardDeffense();
	~TypeCardDeffense();
};

