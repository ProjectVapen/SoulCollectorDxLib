#pragma once
#include "TypeCardBase.h"
#include "Include.h"
class TypeCardMagic:
	public TypeCardBase
{
public:
	TypeCardMagic();
	~TypeCardMagic();
};

