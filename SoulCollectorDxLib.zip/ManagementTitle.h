#pragma once
#include "AppController.h"
class ManagementTitle
{
	public:
		ManagementTitle();
		~ManagementTitle();

		void PushKeyState(AppController::eGetController);

		void PushKeyState();
};

