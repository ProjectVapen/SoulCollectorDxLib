#pragma once
class TypeAttributeBase
{
public:
	TypeAttributeBase();
	~TypeAttributeBase();
};

