#include "TypeCardDeffense.h"


TypeCardDeffense::TypeCardDeffense()
{
}


TypeCardDeffense::~TypeCardDeffense()
{
}
