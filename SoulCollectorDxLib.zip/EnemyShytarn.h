#pragma once
#include "EnemyBase.h"
class EnemyShytarn :
	public EnemyBase
{

	private:

	
	public:
		EnemyShytarn();
		~EnemyShytarn();

		void Render()override;
};

