#include "TypeAttributeFire.h"


TypeAttributeFire::TypeAttributeFire()
{
}


TypeAttributeFire::~TypeAttributeFire()
{
}
