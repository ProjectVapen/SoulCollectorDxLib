#pragma once
#include "Include.h"
class BattleMedium
{
	public:
		BattleMedium();
		~BattleMedium();
};

