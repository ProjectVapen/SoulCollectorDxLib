#pragma once
#include "TypeAttributeBase.h"
#include "Include.h"
class TypeAttributeFire :
	public TypeAttributeBase
{
public:
	TypeAttributeFire();
	~TypeAttributeFire();
};

