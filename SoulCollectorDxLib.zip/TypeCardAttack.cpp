#include "TypeCardAttack.h"


TypeCardAttack::TypeCardAttack()
{
}


TypeCardAttack::~TypeCardAttack()
{
}
